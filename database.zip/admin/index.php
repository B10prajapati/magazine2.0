<?php 
  @header('location: pages/dashboard');
?>