<?php
  include_once $_SERVER['DOCUMENT_ROOT'].'/config/init.php';
  define('UPLOAD_PATH', '../../upload/');
?>