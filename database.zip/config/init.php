<?php 
	include 'config.php';
	include 'functions.php';
	include 'autoload.php';
?>