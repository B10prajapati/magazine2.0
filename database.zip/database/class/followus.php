<?php
class followus extends crudDatabase{
  public function __construct() {
    crudDatabase::__construct('followsus');
  }
}
?>