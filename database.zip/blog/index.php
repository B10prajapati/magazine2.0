<?php
  @header('location: pages/');
?>